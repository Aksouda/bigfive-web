'use strict'

const test = require('ava')

test('basic check', t => {
  t.true(true, 'ava works ok')
})
